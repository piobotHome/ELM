function result_MLR=MLR_train(nan_low,num)
result_MLR=zeros(1,num);
    t=1:48;
for j=1:nan_low
X=[ones(48,1),t'];
b=regress(nan_low(:,j),X);
result_MLR(1,j)=b(1)+b(2)*49;
end



